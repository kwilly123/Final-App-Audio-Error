//
//  Volume.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation

extension TracksViewController: Volume {

    func changeVolume(cell: TrackCell, volume: Float) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        print("Changed Volume for Track \(indexPath?.row ?? 0) to \(volume)")
        projectRef.child("track\(indexPath?.row ?? 0)").updateChildValues(["volume" : volume])
    }
    
    func changeSliderVolume(cell: TrackCell, volume: Float) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        print("Changed Volume for Track \(indexPath?.row ?? 0) to \(volume)")
        projectRef.child("track\(indexPath?.row ?? 0)").updateChildValues(["volume_slider" : volume])
    }
    
}
